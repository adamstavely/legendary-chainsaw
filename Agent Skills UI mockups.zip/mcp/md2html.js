// saved converter source for later agent pages
function convert(src){
  let title='';src=src.replace(/^---\n[\s\S]*?\n---\n?/,'');
  src=src.replace(/^# (.+)\n/m,(_,h)=>{title=h.trim();return '';});
  src=src.replace(/<!--[\s\S]*?-->/g,'');
  const fences=[];
  src=src.replace(/^([ \t]*)(```+)([^\n]*)\n([\s\S]*?)\n[ \t]*\2[ \t]*$/gm,(_,ind,f,meta,body)=>{const lines=body.split('\n').map(l=>l.startsWith(ind)?l.slice(ind.length):l.replace(/^\s+/,''));let b=lines.join('\n');const lang=(meta.trim().split(/[\s{]/)[0]||'');if(/^--8<--/.test(b.trim()))b='# Source for this step is in the a2a-samples repository:\n# '+b.trim().replace(/^--8<-- "/,'').replace(/"$/,'').replace(/^https:\/\/raw\.githubusercontent\.com\/a2aproject\/a2a-samples\/refs\/heads\/main\//,'').replace(/:.*$/,'');fences.push({lang,b});return ind+'\u0002'+(fences.length-1)+'\u0002';});
  const lines=src.split('\n');const out=[];const toc=[];const codes=[];let para=[],list=null;
  const slug=t=>t.toLowerCase().replace(/<[^>]+>/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  const fp=()=>{if(para.length){out.push(`<p style="${S.p}">${inline(para.join(' '),codes)}</p>`);para=[];}};
  const fl=()=>{if(list){const b=(it,o)=>`<${o?'ol':'ul'} style="${S.ul}">${it.map(x=>`<li>${inline(x.t,codes)}${x.k.length?b(x.k,x.ko):''}</li>`).join('')}</${o?'ol':'ul'}>`;out.push(b(list.items,list.ord));list=null;}};
  const fe=i=>{const f=fences[i];return `<div style="display:flex;flex-direction:column;gap:6px;min-width:0">${f.lang==='mermaid'?'<div style="font:500 12px ui-monospace,Menlo,monospace;color:#6F7C8B">Diagram (Mermaid source)</div>':''}<pre style="${S.pre}">${eh(f.b)}</pre></div>`;};
  const sub=(arr)=>convertBody(arr);
  function convertBody(arr){const r=convertLines(arr);return r;}
  function convertLines(L){const saveOut=out.length;return null;}
  for(let i=0;i<lines.length;i++){
    const raw=lines[i],line=raw.trim();
    const ad=raw.match(/^(\s*)(!!!|\?\?\?\+?)\s+(\w+)(?:\s+"([^"]*)")?/);
    if(ad){fp();fl();const ind=ad[1].length;const block=[];let j=i+1;while(j<lines.length&&(!lines[j].trim()||lines[j].search(/\S/)>ind)){block.push(lines[j].slice(Math.min(ind+4,lines[j].length)));j++;}i=j-1;
      const c=CAL[ad[3]]||CAL.note;const inner=convert('# x\n'+block.join('\n').replace(/\u0002(\d+)\u0002/g,(_,n)=>'```'+fences[+n].lang+'\n'+fences[+n].b+'\n```'));
      out.push(`<div style="display:flex;gap:12px;align-items:flex-start;padding:16px 20px;background:${c[0]};border:1px solid ${c[1]};border-radius:6px;font-size:14px;line-height:1.55"><span style="font-weight:600;color:${c[2]};flex:none">${ad[4]?inline(ad[4],codes):c[3]}</span><div style="display:flex;flex-direction:column;gap:10px;min-width:0;flex:1">${inner.html}</div></div>`);continue;}
    const tb=raw.match(/^(\s*)===\s+"([^"]+)"/);
    if(tb){fp();fl();out.push(`<div style="font:600 13px ui-monospace,Menlo,monospace;color:#1D3557;margin-top:4px">${eh(tb[2])}</div>`);continue;}
    if(!line){fp();if(list){let j=i+1;while(j<lines.length&&!lines[j].trim())j++;if(!(j<lines.length&&/^\s*([-*]|\d+\.)\s/.test(lines[j])))fl();}continue;}
    const fm=line.match(/^\u0002(\d+)\u0002$/);if(fm){fp();fl();out.push(fe(+fm[1]));continue;}
    const hm=line.match(/^(#{1,6})\s+(.*)$/);if(hm){fp();fl();const lv=Math.min(4,Math.max(2,hm[1].length));const id=slug(hm[2].replace(/\{#[^}]+\}/,''));if(lv===2)toc.push({id,t:hm[2].replace(/`/g,'').replace(/\*\*/g,'').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1')});out.push(`<h${lv} id="${id}" style="${S['h'+lv]}">${inline(hm[2].replace(/\s*\{#[^}]+\}/,''),codes)}</h${lv}>`);continue;}
    if(/^\|.*\|$/.test(line)){fp();fl();const rows=[];let j=i;while(j<lines.length&&/^\s*\|.*\|\s*$/.test(lines[j])){rows.push(lines[j].trim());j++;}i=j-1;const cells=r=>r.slice(1,-1).split(/(?<!\\)\|/).map(c=>c.trim());const head=cells(rows[0]);const body=rows.slice(2).map(cells);
      out.push(`<div style="border:1px solid #D9E1EA;border-radius:8px;overflow-x:auto;background:#FFFFFF;font-size:14px"><table style="width:100%;border-collapse:collapse"><tr>${head.map(h=>`<th style="text-align:left;padding:10px 14px;background:#F9FCFF;border-bottom:1px solid #D9E1EA;color:#556272;font-weight:600">${inline(h,codes)}</th>`).join('')}</tr>${body.map(r=>`<tr>${r.map(c=>`<td style="padding:10px 14px;border-bottom:1px solid #EDEEF1;vertical-align:top;line-height:1.5">${inline(c,codes)}</td>`).join('')}</tr>`).join('')}</table></div>`);continue;}
    if(/^>\s?/.test(line)){fp();fl();const q=[];let j=i;while(j<lines.length&&/^\s*>/.test(lines[j])){q.push(lines[j].trim().replace(/^>\s?/,''));j++;}i=j-1;out.push(`<div style="padding:12px 18px;border:1px solid #D9E1EA;background:#FFFFFF;border-radius:6px;font-size:15px;line-height:1.6;color:#556272">${inline(q.join(' '),codes)}</div>`);continue;}
    if(/^(---|\*\*\*)$/.test(line)){fp();fl();out.push('<div style="height:1px;background:#D9E1EA;margin:8px 0"></div>');continue;}
    if(/^<\/?(div|img|br|p|span|a)\b/i.test(line)){fp();fl();const txt=line.replace(/<[^>]+>/g,'').trim();if(txt)out.push(`<p style="${S.p}">${inline(txt,codes)}</p>`);continue;}
    const lm=raw.match(/^(\s*)([-*]|\d+\.)\s+(.*)$/);
    if(lm){fp();const ind=lm[1].length,ord=/\d/.test(lm[2]);if(!list)list={items:[],ord,base:ind};const it={t:lm[3],k:[],ko:false};if(ind>list.base+1&&list.items.length){const par=list.items[list.items.length-1];par.k.push(it);par.ko=ord;}else list.items.push(it);continue;}
    if(list&&/^\s+\S/.test(raw)&&!para.length){const last=list.items[list.items.length-1];(last.k.length?last.k[last.k.length-1]:last).t+=' '+line;continue;}
    fl();para.push(line);
  }
  fp();fl();let html=out.join('\n');for(let k=0;k<3;k++)html=html.replace(/\u0001(\d+)\u0001/g,(_,n)=>codes[+n]);html=html.replace(/\u0002(\d+)\u0002/g,(_,n)=>fe(+n));
  return {title,html,toc};}