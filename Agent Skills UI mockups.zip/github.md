repo: adamstavely/modelcontextprotocol
branch: main
path: docs

## Last sync
date: 2026-10-21T06:04:37Z

### Updated in this project
- MCP Learn, Develop, Security and 2026-07-28 specification pages
- External links removed from imported pages
- A2A docs imported from a2aproject/A2A (main) into the Agents section

## Screen map
| Screen | Repo files |
| - | - |
| IMIN Skills.dc.html — MCP › Learn | docs/docs/2026-07-28/getting-started/*, docs/docs/2026-07-28/learn/* |
| IMIN Skills.dc.html — MCP › Develop | docs/docs/2026-07-28/develop/** |
| IMIN Skills.dc.html — MCP › Apps | docs/extensions/apps/* |
| IMIN Skills.dc.html — MCP › Tools | docs/docs/2026-07-28/sdk.mdx, docs/docs/2026-07-28/tools/** |
| IMIN Skills.dc.html — Agents › Coding agents (AGENTS.md) | agentsmd/agents.md: components/*.tsx |
| IMIN Skills.dc.html — MCP › Security | docs/docs/2026-07-28/tutorials/security/* |
| IMIN Skills.dc.html — MCP › Specification | docs/specification/2026-07-28/** |
| IMIN Skills.dc.html — Agents › A2A | a2aproject/A2A: docs/topics/*, docs/tutorials/python/*, docs/specification.md, docs/whats-new-v1.md |
| mcp/pages/*.json (generated) | converted from mcp/docs/**, mcp/spec/** and docs/** (A2A) |
